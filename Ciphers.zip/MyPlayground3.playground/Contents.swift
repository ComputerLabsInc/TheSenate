//: Playground - noun: a place where people can play

import UIKit

/*let messageText = "Horace Mann"
let key = "redredredredredredred"

var message = messageText.lowercased()

let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
let cAlphabet: [Character] = ["x","y","z", "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w"]

var newText = ""
var index: String.Index
var char: Character
var alphabetInd: Array<Any>.Index

for i in 0...message.count-1 {
    index = message.index(message.startIndex, offsetBy: i)
    char = message[index]
    if (char == " ") { newText.append(" ") }
    else {
        alphabetInd = alphabet.index(of: char)!
        newText.append(cAlphabet[alphabetInd])
    }
}

print(newText)*/

let messageText = "eloxzb jxkk"
let key = "redredredredredredred"

var message = messageText
let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
let cAlphabet: [Character] = ["x","y","z", "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w"]

var newText = ""
var index: String.Index
var char: Character
var alphabetInd: Array<Any>.Index

for i in 0...message.count-1 {
    index = message.index(message.startIndex, offsetBy: i)
    char = message[index]
    if (char == " ") { newText.append(" ") }
    else {
        alphabetInd = cAlphabet.index(of: char)!
        newText.append(alphabet[alphabetInd])
    }
}

print(newText)
