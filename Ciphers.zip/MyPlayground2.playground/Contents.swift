//: Playground - noun: a place where people can play

import UIKit

let messageText = "Horace Mann"
let key = "redredredredredredred"

var message = messageText.lowercased()
message = message.replacingOccurrences(of: " ", with: "")
var newText = ""
let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
var messageArr: [String] = []
var keyArr: [String] = []
var strIndex: String.Index
var keyChar: Character
var char: Character


for i in 0...message.count - 1 {
    strIndex = message.index(message.startIndex, offsetBy: i)
    char = message[strIndex]
    keyChar = key[strIndex]
    messageArr.append(String(alphabet.index(of: char)! + 65, radix: 2))
    keyArr.append(String(alphabet.index(of: keyChar)! + 65, radix: 2))
}

var keyNum: String
var xor: [String] = []
var xorStr: String = ""
var a: String.Index
var num: String

for i in 0...messageArr.count-1 {
    xorStr = ""
    num = messageArr[i]
    keyNum = keyArr[i]
    for j in 0...6 {
        strIndex = num.index(num.startIndex, offsetBy: j)
        char = num[strIndex]
        keyChar = keyNum[strIndex]
        if (char != keyChar) { xorStr.append("1") }
        else { xorStr.append("0") }
    }
    xor.append(xorStr)
}

message = messageText

for i in 0...message.count - 1 {
    if (message[message.index(message.startIndex, offsetBy: i)] == " ") {
        xor.insert(",", at: i)
    }
}

var returnStr = ""

for i in 0...xor.count - 1 {
    if (i > 0) {
        returnStr.append(" ")
    }
    returnStr.append(xor[i])
}

print(returnStr)

/*let messageText = "0011010 0001010 0010110 0010011 0000110 0000001 , 0011111 0000100 0001010 0011100"
let key = "redredredredredredred"

var message = messageText
message = message.replacingOccurrences(of: " ", with: "")
message = message.replacingOccurrences(of: ",", with: "")
var newText = message
let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
var messageArr: [String] = []
var keyArr: [String] = []
var strIndex: String.Index
var keyChar: Character
var str = ""
var keyNum: String
var num: String
var xor: [String] = []
var xorStr: String
var a: String.Index
var char: Character
var value: Int
var total: Int

newText = message

for _ in 0...(message.count-1)/7 {
    str = String(newText[newText.startIndex..<newText.index(newText.startIndex, offsetBy: 7)])
    messageArr.append(str)
    newText.removeSubrange(newText.startIndex..<newText.index(newText.startIndex, offsetBy: 7))
}

for char in key {
    keyArr.append(String(alphabet.index(of: char)! + 65, radix: 2))
}

for i in 0...messageArr.count-1 {
    xorStr = ""
    num = messageArr[i]
    keyNum = keyArr[i]
    for j in 0...6 {
        strIndex = num.index(num.startIndex, offsetBy: j)
        char = num[strIndex]
        keyChar = keyNum[strIndex]
        if (char != keyChar) { xorStr.append("1") }
        else { xorStr.append("0") }
    }
    xor.append(xorStr)
}

newText = ""

for i in 0...xor.count-1 {
    value = 1
    total = 0
    for char in xor[i].reversed() {
        if (char == "1") { total += value }
        value *= 2
    }
    newText.append(alphabet[total - 65])
}

message = messageText
message = message.replacingOccurrences(of: " ", with: "")
str = ""
for _ in 0...(message.count-1)/7 {
    if (message[message.startIndex] == "," ) {
        str.append(",")
        message.removeSubrange(message.startIndex...message.startIndex)
    }
    else {
        str.append("a")
        message.removeSubrange(message.startIndex..<message.index(message.startIndex, offsetBy: 7))
    }
}

while (str.range(of: ",") != nil) {
    strIndex = str.index(of: ",")!
    str.replaceSubrange(strIndex...strIndex, with: "a")
    newText.insert(" ", at: strIndex)
}

print(newText)*/
