//
//  MessagesViewController.swift
//  Cipher MessagesExtension
//
//  Created by Vikram Ostrander on 5/3/18.
//  Copyright © 2018 Vikram Ostrander. All rights reserved.
//

import UIKit
import Messages

class MessagesViewController: MSMessagesAppViewController {
    @IBOutlet weak var messageField: UITextField!
    @IBOutlet weak var keyField: UITextField!
    @IBOutlet weak var ceasar: UIButton!
    @IBOutlet weak var vernan: UIButton!
    @IBOutlet weak var vigenére: UIButton!
    @IBOutlet weak var cipherField: UITextField!
    @IBOutlet weak var keyCipher: UITextField!
    @IBOutlet weak var decode: UIButton!
    @IBOutlet weak var output: UILabel!
    
    //MARK: – Sending Messages
    //MARK: – Ceasar Cipher
    @IBAction func ceasarPress(_ sender: UIButton) {
        let messageText = messageField.text!.lowercased()
        
        let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        let cAlphabet: [Character] = ["x","y","z", "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w"]
        
        var newText = ""
        var index: String.Index
        var char: Character
        var alphabetInd: Array<Any>.Index
        
        for i in 0...messageText.count-1 {
            index = messageText.index(messageText.startIndex, offsetBy: i)
            char = messageText[index]
            if (char == " ") { newText.append(" ") }
            else {
                alphabetInd = alphabet.index(of: char)!
                newText.append(cAlphabet[alphabetInd])
            }
        }
        
        sendMessage(text: "1" + newText)
    }
    
    //MARK: – Vernan Cipher
    @IBAction func vernanPress(_ sender: UIButton) {
        let messageText = messageField.text!
        let key = fixKey()
        
        var message = messageText.lowercased()
        message = message.replacingOccurrences(of: " ", with: "")
        let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        var messageArr: [String] = []
        var keyArr: [String] = []
        var strIndex: String.Index
        var keyChar: Character
        var char: Character
        
        
        for i in 0...message.count - 1 {
            strIndex = message.index(message.startIndex, offsetBy: i)
            char = message[strIndex]
            keyChar = key[strIndex]
            messageArr.append(String(alphabet.index(of: char)! + 65, radix: 2))
            keyArr.append(String(alphabet.index(of: keyChar)! + 65, radix: 2))
        }
        
        var keyNum: String
        var xor: [String] = []
        var xorStr: String = ""
        var num: String
        
        for i in 0...messageArr.count-1 {
            xorStr = ""
            num = messageArr[i]
            keyNum = keyArr[i]
            for j in 0...6 {
                strIndex = num.index(num.startIndex, offsetBy: j)
                char = num[strIndex]
                keyChar = keyNum[strIndex]
                if (char != keyChar) { xorStr.append("1") }
                else { xorStr.append("0") }
            }
            xor.append(xorStr)
        }
        
        message = messageText
        
        for i in 0...message.count - 1 {
            if (message[message.index(message.startIndex, offsetBy: i)] == " ") {
                xor.insert(",", at: i)
            }
        }
        
        var returnStr = ""
        
        for i in 0...xor.count - 1 {
            if (i > 0) {
                returnStr.append(" ")
            }
            returnStr.append(xor[i])
        }
        
        sendMessage(text: "2" + returnStr)
    }
    
    //MARK: – Vigenére Cipher
    @IBAction func vigenérePress(_ sender: UIButton) {
        let messageText = messageField.text!
        let key = fixKey()
        
        var message = messageText.lowercased()
        message = message.replacingOccurrences(of: " ", with: "")
        var newText = ""
        
        let array: [[Character]] = [
            ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"],
            ["b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a"],
            ["c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b"],
            ["d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c"],
            ["e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d"],
            ["f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e"],
            ["g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f"],
            ["h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g"],
            ["i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h"],
            ["j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i"],
            ["k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j"],
            ["l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"],
            ["m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"],
            ["n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m"],
            ["o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"],
            ["p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o"],
            ["q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p"],
            ["r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q"],
            ["s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r"],
            ["t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s"],
            ["u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t"],
            ["v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u"],
            ["w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v"],
            ["x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w"],
            ["y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x"],
            ["z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y"]
        ]
        
        var index: String.Index
        var keyChar: Character
        var rows: Array<Any>.Index
        var columns: Array<Any>.Index
        let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        
        for char in message {
            index = message.index(of: char)!
            message.replaceSubrange(index...index, with: "_")
            keyChar = key[index]
            rows = alphabet.index(of: keyChar)!
            columns = alphabet.index(of: char)!
            newText.append(array[rows][columns])
        }
        
        message = messageText
        while (message.range(of: " ") != nil) {
            index = message.index(of: " ")!
            message.replaceSubrange(index...index, with: "a")
            newText.insert(" ", at: index)
        }
        
        sendMessage(text: "3" + newText)
    }
    
    //MARK: – Recieving Messages
    @IBAction func decodePress(_ sender: UIButton) {
        var cipherText: String = cipherField.text!
        cipherText.remove(at: cipherText.startIndex)
        if (cipherField.text![cipherField.text!.startIndex] == "1") {
            output.text = decodeCeasar(messageText: cipherText)
        }
        
        if (cipherField.text![cipherField.text!.startIndex] == "2") {
            output.text = decodeVernan(messageText: cipherText)
        }
        
        if (cipherField.text![cipherField.text!.startIndex] == "3") {
            output.text = decodeVigenére(messageText: cipherText)
        }
    }
    
    //MARK: – Decoding Ceasar
    func decodeCeasar(messageText: String) -> String {
        
        let message = messageText
        let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        let cAlphabet: [Character] = ["x","y","z", "a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w"]
        
        var newText = ""
        var index: String.Index
        var char: Character
        var alphabetInd: Array<Any>.Index
        
        for i in 0...message.count-1 {
            index = message.index(message.startIndex, offsetBy: i)
            char = message[index]
            if (char == " ") { newText.append(" ") }
            else {
                alphabetInd = cAlphabet.index(of: char)!
                newText.append(alphabet[alphabetInd])
            }
        }
        
        return newText
    }
    
    //MARK: – Decoding Vernan
    func decodeVernan(messageText: String) -> String {
        let key = fixKey()
        
        var message = messageText
        message = message.replacingOccurrences(of: " ", with: "")
        message = message.replacingOccurrences(of: ",", with: "")
        var newText = message
        let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        var messageArr: [String] = []
        var keyArr: [String] = []
        var strIndex: String.Index
        var keyChar: Character
        var str = ""
        var keyNum: String
        var num: String
        var xor: [String] = []
        var xorStr: String
        var char: Character
        var value: Int
        var total: Int
        
        newText = message
        
        for _ in 0...(message.count-1)/7 {
            str = String(newText[newText.startIndex..<newText.index(newText.startIndex, offsetBy: 7)])
            messageArr.append(str)
            newText.removeSubrange(newText.startIndex..<newText.index(newText.startIndex, offsetBy: 7))
        }
        
        for char in key {
            keyArr.append(String(alphabet.index(of: char)! + 65, radix: 2))
        }
        
        for i in 0...messageArr.count-1 {
            xorStr = ""
            num = messageArr[i]
            keyNum = keyArr[i]
            for j in 0...6 {
                strIndex = num.index(num.startIndex, offsetBy: j)
                char = num[strIndex]
                keyChar = keyNum[strIndex]
                if (char != keyChar) { xorStr.append("1") }
                else { xorStr.append("0") }
            }
            xor.append(xorStr)
        }
        
        newText = ""
        
        for i in 0...xor.count-1 {
            value = 1
            total = 0
            for char in xor[i].reversed() {
                if (char == "1") { total += value }
                value *= 2
            }
            newText.append(alphabet[total - 65])
        }
        
        message = messageText
        message = message.replacingOccurrences(of: " ", with: "")
        str = ""
        for _ in 0...(message.count-1)/7 {
            if (message[message.startIndex] == "," ) {
                str.append(",")
                message.removeSubrange(message.startIndex...message.startIndex)
            }
            else {
                str.append("a")
                message.removeSubrange(message.startIndex..<message.index(message.startIndex, offsetBy: 7))
            }
        }
        
        while (str.range(of: ",") != nil) {
            strIndex = str.index(of: ",")!
            str.replaceSubrange(strIndex...strIndex, with: "a")
            newText.insert(" ", at: strIndex)
        }
        
        return newText
    }
    
    //MARK: – Decoding Vigenére
    func decodeVigenére(messageText: String) -> String {
        let key = fixKey()
        
        var message = messageText.lowercased()
        message = message.replacingOccurrences(of: " ", with: "")
        var newText = ""
        
        let array: [[Character]] = [
            ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"],
            ["b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a"],
            ["c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b"],
            ["d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c"],
            ["e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d"],
            ["f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e"],
            ["g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f"],
            ["h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g"],
            ["i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h"],
            ["j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i"],
            ["k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j"],
            ["l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k"],
            ["m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"],
            ["n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m"],
            ["o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"],
            ["p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o"],
            ["q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p"],
            ["r", "s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q"],
            ["s", "t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r"],
            ["t", "u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s"],
            ["u", "v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t"],
            ["v", "w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u"],
            ["w", "x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v"],
            ["x", "y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w"],
            ["y", "z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x"],
            ["z", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y"]
        ]
        
        var index: String.Index
        var keyChar: Character
        var rows: Array<Any>.Index
        var columns: Array<Any>.Index = 0
        let alphabet: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
        
        for char in message {
            index = message.index(of: char)!
            message.replaceSubrange(index...index, with: "_")
            keyChar = key[index]
            rows = alphabet.index(of: keyChar)!
            columns = array[rows].index(of: char)!
            newText.append(array[0][columns])
        }
        
        message = messageText
        while (message.range(of: " ") != nil) {
            index = message.index(of: " ")!
            message.replaceSubrange(index...index, with: "a")
            newText.insert(" ", at: index)
        }
        
        return newText
    }
    
    //MARK: – Other Functions
    func sendMessage(text: String) {
        activeConversation?.insertText(text, completionHandler: nil)
    }
    
    func fixKey() -> String {
        var newKey = keyField.text!
        
        if (newKey.count >= messageField.text!.count) {
            return newKey
        }
        
        while (0 < 1) {
            newKey.append(contentsOf: keyField.text!)
            if (newKey.count >= messageField.text!.count) {
                break
            }
        }
        return newKey
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Conversation Handling
    
    override func willBecomeActive(with conversation: MSConversation) {
        // Called when the extension is about to move from the inactive to active state.
        // This will happen when the extension is about to present UI.
        
        // Use this method to configure the extension and restore previously stored state.
    }
    
    override func didResignActive(with conversation: MSConversation) {
        // Called when the extension is about to move from the active to inactive state.
        // This will happen when the user dissmises the extension, changes to a different
        // conversation or quits Messages.
        
        // Use this method to release shared resources, save user data, invalidate timers,
        // and store enough state information to restore your extension to its current state
        // in case it is terminated later.
    }
   
    override func didReceive(_ message: MSMessage, conversation: MSConversation) {
        // Called when a message arrives that was generated by another instance of this
        // extension on a remote device.
        
        // Use this method to trigger UI updates in response to the message.
    }
    
    override func didStartSending(_ message: MSMessage, conversation: MSConversation) {
        // Called when the user taps the send button.
    }
    
    override func didCancelSending(_ message: MSMessage, conversation: MSConversation) {
        // Called when the user deletes the message without sending it.
    
        // Use this to clean up state related to the deleted message.
    }
    
    override func willTransition(to presentationStyle: MSMessagesAppPresentationStyle) {
        // Called before the extension transitions to a new presentation style.
    
        // Use this method to prepare for the change in presentation style.
    }
    
    override func didTransition(to presentationStyle: MSMessagesAppPresentationStyle) {
        // Called after the extension transitions to a new presentation style.
    
        // Use this method to finalize any behaviors associated with the change in presentation style.
    }

}
